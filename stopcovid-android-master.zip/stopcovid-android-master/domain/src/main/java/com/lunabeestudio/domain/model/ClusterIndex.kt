package com.lunabeestudio.domain.model

class ClusterIndex(
    val iteration: Int,
    val clusterPrefixList: List<String>
)
