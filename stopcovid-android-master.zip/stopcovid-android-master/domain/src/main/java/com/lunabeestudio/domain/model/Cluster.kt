package com.lunabeestudio.domain.model

class Cluster(
    val ltid: String,
    val exposures: List<ClusterExposure>?
)