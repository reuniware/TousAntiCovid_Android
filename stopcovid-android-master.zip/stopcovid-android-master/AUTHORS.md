Ce composant à été écrit par Lunabee Studio

Les personnes suivantes ont contribué
Darth Vader (stopcovid@lunabee.com)
Kick-Ass (stopcovid@lunabee.com)
Batman (stopcovid@lunabee.com)
Watchman (stopcovid@lunabee.com)
