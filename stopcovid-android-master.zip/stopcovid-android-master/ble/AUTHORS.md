# Authors

* Naos <dev1(dot)stopcovid(at)orange(dot)com>
* Merak <dev2(dot)stopcovid(at)orange(dot)com>
* Wezen <dev3(dot)stopcovid(at)orange(dot)com>
* Kochab <dev4(dot)stopcovid(at)orange(dot)com>
* Régulus <dev5(dot)stopcovid(at)orange(dot)com>
* Eltanin <dev6(dot)stopcovid(at)orange(dot)com>
* Arcturus <dev7(dot)stopcovid(at)orange(dot)com>
* Bételgeuse <dev8(dot)stopcovid(at)orange(dot)com>
* Nunki <dev9(dot)stopcovid(at)orange(dot)com>
* Wei <dev10(dot)stopcovid(at)orange(dot)com>
* Murzim <dev11(dot)stopcovid(at)orange(dot)com>
* Sirius <dev20(dot)stopcovid(at)orange(dot)com>
