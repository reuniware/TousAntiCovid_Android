package dgca.verifier.app.decoder.model

enum class CertificateType {
    UNKNOWN,VACCINATION,RECOVERY,TEST
}